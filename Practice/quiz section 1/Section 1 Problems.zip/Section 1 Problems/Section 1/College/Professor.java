public class Professor {

    
}
