public class Example {
    public static int one() {
        return 1;
    }

    public static int two() {
        return 2;
    }
}